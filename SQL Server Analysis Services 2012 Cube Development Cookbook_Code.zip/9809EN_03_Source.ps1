# script to create a new partition based on existing partition
#load the Analysis Services assembly first so we can instantiate Analysis Services object:
[Reflection.Assembly]::LoadFrom("E:\Program Files\Microsoft SQL Server\110\SDK\Assemblies\Microsoft.AnalysisServices.dll")|out-null
$instance="Julia-PC\SQL2012"
$amoServer= new-object Microsoft.AnalysisServices.Server
#connect to the instance
$amoServer.Connect($instance)

#connect to the db, cube and measure group of interest: 

$db=$amoServer.databases.GetByName("ssas_cookbook_chapter3")
$cube = $db.cubes.GetByName("AdventureWorksSample")
$mg=$cube.MeasureGroups.GetByName("Fact Reseller Sales")

#clone the existing partition:
$new_partition = $mg.partitions.GetByName("Reseller Sales 2006").clone()

# set id, name and query definition properties for the new partition:
$new_partition.id = "Reseller Sales 2008"
$new_partition.name = "Reseller Sales 2008"
$new_partition.Source.QueryDefinition = "SELECT * FROM FactResellerSales WHERE DueDateKey BETWEEN 20080101 AND 20081231"

# store new partition's identifier in a variable for the next step:
$partition_id = $amoServer.Databases[$db].Cubes[$cube].MeasureGroups[0].partitions.Add($new_partition)

# send the new partition definition to the server: 
$amoServer.Databases[$db].cubes[$cube].MeasureGroups[0].Partitions[$partition_id].Update()
$amoServer.databases[$db].update()

#disconnect from the server
$amoServer.disconnect()


