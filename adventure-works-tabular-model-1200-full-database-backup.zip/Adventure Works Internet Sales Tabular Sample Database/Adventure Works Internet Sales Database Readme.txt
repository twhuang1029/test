This Analysis Services Tabular model sample database is provided without warranty.

In order to process tables, you'll need AdventureWorksDW2014 sample database installed on a SQL Server instance. This database serves as the datasource.

- If your AdventureWorksDW2014 sample database (as datasource) is on a different server or named instance, you will need to edit the Data Source property in the Connection String. In SSMS, Databases > Adventure Works Internet Sales > Connections, right-click Adventure Works DB from SQL, Properties > Connection String.

- You may need to specify Impersonation Mode user credentials to connect to the AdventureWorksDW2014 datasource. In SSMS, Databases > Adventure Works Internet Sales > Connections, right-click Adventure Works DB from SQL, Properties > Impersonation Info.

To determine if connection string and impersonation mode properties are set correctly, do a process full on one or more tables.


 