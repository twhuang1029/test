truncate table [dbo].[Customer]
truncate table [dbo].[LogSourceFile]