﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Application
{
    public partial class LocalProcessingMode : Form
    {
        public LocalProcessingMode()
        {
            InitializeComponent();
        }

        private void LocalProcessingMode_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'AdventureWorksDW2012DataSet1.SalesView' table. You can move, or remove it, as needed.
            this.SalesViewTableAdapter.Fill(this.AdventureWorksDW2012DataSet1.SalesView);

            this.reportViewer1.RefreshReport();
        }
    }
}
