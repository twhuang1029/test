﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Application
{
    public partial class FilterForm : Form
    {
        public FilterForm()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            string BingParamValue = string.Empty;
            if (rbtYes.Checked)
                BingParamValue = "Visible";
            else
                BingParamValue = "Hidden";

            RemoteProcessingMode reportFrm = new RemoteProcessingMode();

            ReportParameter BingParam = new ReportParameter("ShowBingMaps", BingParamValue);

            reportFrm.rvwSales.ServerReport.SetParameters(new ReportParameter[] { BingParam });
            reportFrm.rvwSales.ShowParameterPrompts = false;
            reportFrm.rvwSales.RefreshReport();
            reportFrm.Show();
        }
    }
}
