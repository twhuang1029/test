﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMX_Query_through_Application
{
    public partial class InputData : Form
    {
        public InputData()
        {
            InitializeComponent();
        }

        private void InputData_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'adventureWorksDW2012DataSet.ProspectiveBuyer' table. You can move, or remove it, as needed.
            this.prospectiveBuyerTableAdapter.Fill(this.adventureWorksDW2012DataSet.ProspectiveBuyer);

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            this.prospectiveBuyerTableAdapter.Update(this.adventureWorksDW2012DataSet.ProspectiveBuyer);
        }

        private void btnPredict_Click(object sender, EventArgs e)
        {
            Prediction frmPrediction = new Prediction();
            frmPrediction.Show();
        }
    }
}
