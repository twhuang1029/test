﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.AnalysisServices.AdomdClient;

namespace DMX_Query_through_Application
{
    public partial class Prediction : Form
    {
        public Prediction()
        {
            InitializeComponent();
        }

        private void btnPredict_Click(object sender, EventArgs e)
        {
            
            
        }

        private void Prediction_Load(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            AdomdConnection Conn = new AdomdConnection("Data Source=localhost;Catalog=Chapter 08 Data Mining Predictive Models");
            AdomdDataAdapter DMXCmd = new AdomdDataAdapter();
            DMXCmd.SelectCommand = new AdomdCommand();
            DMXCmd.SelectCommand.Connection = Conn;

            DMXCmd.SelectCommand.CommandText = "SELECT " +
  "t.[FirstName], " +
  "t.[LastName], " +
  "t.[EmailAddress], " +
  "t.[Phone], " +
  "t.[Salutation], " +
  "(PredictProbability([Target Mail Decision Tree].[Bike Buyer],1)) as [Bike Buyer] " +
"From " +
 " [Target Mail Decision Tree] " +
"PREDICTION JOIN " +
 " OPENQUERY([Adventure Works DW2012], " +
  "  'SELECT " +
   "   [FirstName], " +
    "  [LastName], " +
     " [EmailAddress], " +
     " [Phone], " +
     " [Salutation], " +
     " [MaritalStatus], " +
     " [Gender], " +
     " [YearlyIncome], " +
     " [TotalChildren], " +
     " [NumberChildrenAtHome], " +
     " [HouseOwnerFlag], " +
     " [NumberCarsOwned] " +
    "FROM " +
     " [dbo].[ProspectiveBuyer] " +
    "') AS t " +
"ON " +
 " [Target Mail Decision Tree].[Marital Status] = t.[MaritalStatus] AND " +
 " [Target Mail Decision Tree].[Gender] = t.[Gender] AND " +
 " [Target Mail Decision Tree].[Yearly Income] = t.[YearlyIncome] AND " +
 " [Target Mail Decision Tree].[Total Children] = t.[TotalChildren] AND " +
 " [Target Mail Decision Tree].[Number Children At Home] = t.[NumberChildrenAtHome] AND " +
 " [Target Mail Decision Tree].[House Owner Flag] = t.[HouseOwnerFlag] AND " +
 " [Target Mail Decision Tree].[Number Cars Owned] = t.[NumberCarsOwned]  " +
"where PredictProbability([Target Mail Decision Tree].[Bike Buyer],1)>0.5 " +
"order by PredictProbability([Target Mail Decision Tree].[Bike Buyer],1) desc ";
            Conn.Open();
            DMXCmd.Fill(ds, "tbl");
            Conn.Close();
            grdPredictionResult.DataSource = new DataView(ds.Tables[0]);
        }
    }
}
