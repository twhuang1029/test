You can use these Excel files instead of typing everything from scratch,
just make sure you rename the file into "Metadata.xlsx" (without the recipe part)
when you place it in C:\Temp as recipes expect.
