SELECT * FROM 
OPENQUERY(MetadataExcel, 'SELECT * FROM [Report_Items$]')